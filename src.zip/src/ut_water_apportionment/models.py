from dataclasses import dataclass, field, fields, is_dataclass
from datetime import date
from enum import Enum
from math import floor, isclose, isfinite
import json
from pathlib import Path
from .loss_models import (
    LossDefinition,
    LossInterval,
    ResolvedLossRelation,
)


DEFAULT_TRXN_PRIORITY = 999999999
SLACK_TRXN_PRIORITY = 1e100


'''
4/14/2026 - DJJONES
The intent of this file is to create stand-alone classes so the solver can be
used outside of the context of the container app, if neccessary. This is why
many of the classes defined here are very duplicative of classes defined in the
container app.
'''


@dataclass
class SolverInput:
    accounting_graph: 'AccountingGraph'
    txns: 'list[PathTrxn | TrxnGroup]'
    measurements: 'MeasurementCollection'
    beg_date: str
    end_date: str

    # 2026-07-17: Maps flow_id -> list of daily natural flow values matching the date range
    external_natural_flows: dict[str, dict[str, float]] = field(default_factory=dict)

    def __post_init__(self):
        try:
            beg = date.fromisoformat(self.beg_date)
            end = date.fromisoformat(self.end_date)
        except ValueError as exc:
            raise ValueError(
                "Solver dates must use YYYY-MM-DD format: "
                f"{self.beg_date!r} to {self.end_date!r}"
            ) from exc

        if end < beg:
            raise ValueError(
                f"Solver end_date {self.end_date} "
                f"is before beg_date {self.beg_date}."
            )

        measurement_beg = date.fromisoformat(
            self.measurements.beg_date
        )
        measurement_end = date.fromisoformat(
            self.measurements.end_date
        )

        if beg < measurement_beg or end > measurement_end:
            raise ValueError(
                "Solver date range must be contained within the "
                "measurement date range: "
                f"solver={self.beg_date} to {self.end_date}, "
                f"measurements={self.measurements.beg_date} "
                f"to {self.measurements.end_date}."
            )


    def to_dict(self) -> dict:
        """
        Convert this SolverInput to a JSON-compatible dictionary.

        Only dataclass fields that participate in construction are included.
        Runtime/cache fields such as MeasurementCollection._series_by_id are
        intentionally omitted.
        """

        def convert(value):
            if isinstance(value, Enum):
                return value.value

            if is_dataclass(value):
                return {
                    f.name: convert(getattr(value, f.name))
                    for f in fields(value)
                    if f.init
                }

            if isinstance(value, dict):
                return {
                    str(key): convert(item)
                    for key, item in value.items()
                }

            if isinstance(value, (list, tuple)):
                return [convert(item) for item in value]

            return value

        return convert(self) # type: ignore

    def to_json_text(self, indent:int | None = None):
        """
        Convert this SolverInput to JSON text.
        """

        payload = {
            "format": "ut-water-apportionment-solver-input",
            "version": 1,
            "input": self.to_dict(),
        }

        return json.dumps(
            payload,
            indent=indent,
            allow_nan=False,
        )


    def to_json(
        self,
        filename: str | Path,
        *,
        indent: int | None = None,
    ) -> None:
        """
        Save this SolverInput to a portable JSON file.
        """

        Path(filename).write_text(
            self.to_json_text(indent),
            encoding="utf-8",
        )


    @classmethod
    def from_dict(cls, data: dict) -> "SolverInput":
        """
        Reconstruct a SolverInput from the dictionary produced by to_dict().
        """

        def parse_enum(enum_type, value):
            if value is None:
                return None

            if isinstance(value, enum_type):
                return value

            # Normal JSON produced by to_dict() stores Enum.value.
            try:
                return enum_type(value)
            except ValueError:
                pass

            # Also tolerate strings such as "ZoneTypes.STREAM" or "STREAM".
            name = str(value).split(".")[-1]

            try:
                return enum_type[name]
            except KeyError as exc:
                raise ValueError(
                    f"Unknown {enum_type.__name__} value: {value!r}"
                ) from exc


        def parse_loss(value) -> LossDefinition:
            if value is None:
                return LossDefinition()

            if isinstance(value, LossDefinition):
                return value

            segments = tuple(
                ResolvedLossRelation(
                    segment_index=int(segment["segment_index"]),
                    min_driver_flow=float(
                        segment["min_driver_flow"]
                    ),
                    max_driver_flow=(
                        None
                        if segment["max_driver_flow"] is None
                        else float(segment["max_driver_flow"])
                    ),
                    loss_slope=float(segment["loss_slope"]),
                    loss_intercept=float(
                        segment["loss_intercept"]
                    ),
                )
                for segment in value.get("segments", [])
            )

            intervals = tuple(
                LossInterval(
                    beg_date=str(interval["beg_date"]),
                    end_date=str(interval["end_date"]),
                    loss=parse_loss(interval["loss"]),
                )
                for interval in value.get("intervals", [])
            )

            default_data = value.get("default")

            return LossDefinition(
                segments=segments,
                intervals=intervals,
                default=(
                    None
                    if default_data is None
                    else parse_loss(default_data)
                ),
            )


        def parse_limit(value):
            if value is None:
                return None

            if isinstance(value, (int, float)):
                return value

            if isinstance(value, AccountingLimit):
                return value

            return AccountingLimit(
                intervals=[
                    AccountingLimitInterval(
                        beg_date=str(interval["beg_date"]),
                        end_date=str(interval["end_date"]),
                        value=float(interval["value"]),
                    )
                    for interval in value["intervals"]
                ]
            )


        def parse_measurement(value) -> FlowMeasurement:
            return FlowMeasurement(
                measurement_id=str(value["measurement_id"]),
                adjustment_factor=float(
                    value.get("adjustment_factor", 1.0)
                ),
            )


        def parse_transaction(value):
            common = dict(
                id=str(value["id"]),
                priority=float(value["priority"]),
                upper_limit=parse_limit(
                    value.get("upper_limit")
                ),
                cumulative_limit=value.get(
                    "cumulative_limit"
                ),
                cumulative_reset_before_MMDD=value.get(
                    "cumulative_reset_before_MMDD"
                ),
                call_limit=parse_limit(
                    value.get("call_limit")
                ),
                wrnum=value.get("wrnum"),
                beg_date=value.get("beg_date"),
                end_date=value.get("end_date"),
            )

            if "children_trxns" in value:
                return TrxnGroup(
                    **common,
                    children_trxns=[
                        parse_transaction(child)
                        for child
                        in value.get("children_trxns", [])
                    ],
                )

            return PathTrxn(
                **common,
                path=[
                    TrxnPathItem(
                        flow_id=str(item["flow_id"]),
                        factor=float(
                            item.get("factor", 1.0)
                        ),
                        expected_values=(
                            None
                            if item.get("expected_values") is None
                            else list(
                                item["expected_values"]
                            )
                        ),
                        loss_before=float(
                            item.get("loss_before", 0.0)
                        ),
                        loss_after=float(
                            item.get("loss_after", 0.0)
                        ),
                        remaining_factor=float(
                            item.get(
                                "remaining_factor",
                                1.0,
                            )
                        ),
                    )
                    for item in value.get("path", [])
                ],
                from_account=value.get("from_account"),
                to_account=value.get("to_account"),
                is_slack=bool(
                    value.get("is_slack", False)
                ),
            )


        graph_data = data["accounting_graph"]

        graph = AccountingGraph(
            zones=[
                Zone(
                    id=str(zone["id"]),
                    type=parse_enum(
                        ZoneTypes,
                        zone["type"],
                    ),
                    storage_meas_ids=[
                        str(value)
                        for value
                        in zone.get(
                            "storage_meas_ids",
                            [],
                        )
                    ],
                    accounts=[
                        ZoneAccount(
                            id=str(account["id"]),
                            starting_balance=float(
                                account.get(
                                    "starting_balance",
                                    0.0,
                                )
                            ),
                            balance_ceiling=(
                                None
                                if account.get(
                                    "balance_ceiling"
                                ) is None
                                else float(
                                    account[
                                        "balance_ceiling"
                                    ]
                                )
                            ),
                            balance_floor=(
                                None
                                if account.get(
                                    "balance_floor"
                                ) is None
                                else float(
                                    account[
                                        "balance_floor"
                                    ]
                                )
                            ),
                        )
                        for account
                        in zone.get("accounts", [])
                    ],
                )
                for zone in graph_data["zones"]
            ],

            interzone_flows=[
                InterzoneFlow(
                    id=str(flow["id"]),
                    from_zone=str(flow["from_zone"]),
                    to_zone=str(flow["to_zone"]),
                    bidirectional=bool(
                        flow.get(
                            "bidirectional",
                            False,
                        )
                    ),
                    flow_type=parse_enum(
                        FlowComponentsTypes,
                        flow.get(
                            "flow_type",
                            FlowComponentsTypes
                            .OBSERVATION
                            .value,
                        ),
                    ),
                    flow_measurements=[
                        parse_measurement(value)
                        for value
                        in flow.get(
                            "flow_measurements",
                            [],
                        )
                    ],
                    lag_from_zone=float(
                        flow.get(
                            "lag_from_zone",
                            0.0,
                        )
                    ),
                    lag_to_zone=float(
                        flow.get(
                            "lag_to_zone",
                            0.0,
                        )
                    ),
                    loss_from_zone=parse_loss(
                        flow.get("loss_from_zone")
                    ),
                    loss_to_zone=parse_loss(
                        flow.get("loss_to_zone")
                    ),
                    natural_flow_mode=(
                        None
                        if flow.get(
                            "natural_flow_mode"
                        ) is None
                        else parse_enum(
                            NaturalFlowMode,
                            flow[
                                "natural_flow_mode"
                            ],
                        )
                    ),
                    nf_measurements=[
                        parse_measurement(value)
                        for value
                        in flow.get(
                            "nf_measurements",
                            [],
                        )
                    ],
                    beg_date=str(
                        flow.get(
                            "beg_date",
                            "1000-01-01",
                        )
                    ),
                    end_date=str(
                        flow.get(
                            "end_date",
                            "9999-12-31",
                        )
                    ),
                )
                for flow
                in graph_data["interzone_flows"]
            ],
        )


        measurement_data = data["measurements"]

        measurements = MeasurementCollection(
            series=[
                MeasurementSeries(
                    id=str(series["id"]),
                    values=list(series["values"]),
                )
                for series
                in measurement_data["series"]
            ],
            beg_date=str(
                measurement_data["beg_date"]
            ),
            end_date=str(
                measurement_data["end_date"]
            ),
        )


        return cls(
            accounting_graph=graph,
            txns=[
                parse_transaction(value)
                for value in data["txns"]
            ],
            measurements=measurements,
            beg_date=str(data["beg_date"]),
            end_date=str(data["end_date"]),
            external_natural_flows={
                str(flow_id): {
                    str(date): float(value)
                    for date, value
                    in values.items()
                }
                for flow_id, values
                in data.get(
                    "external_natural_flows",
                    {},
                ).items()
            },
        )


    @classmethod
    def from_json(
        cls,
        filename: str | Path,
    ) -> "SolverInput":
        """
        Load a SolverInput saved by to_json().

        A bare SolverInput dictionary is also accepted for convenience.
        """

        payload = json.loads(
            Path(filename).read_text(
                encoding="utf-8"
            )
        )

        if (
            isinstance(payload, dict)
            and payload.get("format")
            == "ut-water-apportionment-solver-input"
        ):
            version = payload.get("version")

            if version != 1:
                raise ValueError(
                    "Unsupported SolverInput JSON "
                    f"version: {version!r}"
                )

            data = payload["input"]

        else:
            # Also accept an unwrapped SolverInput dictionary.
            data = payload

        return cls.from_dict(data)


@dataclass
class SolverOutput:
    apportionments: list['SolverOutputApportionment']
    solver_backend: str | None = None
    solve_method: str = "lp"
    compilation_report: dict | None = None

    def get_result_value(self,
                         date:str|None=None,
                         trxn_id:str|None=None,
                         flow_id:str|None=None
                         ) -> list['SolverOutputApportionment']:
        output = []
        for i in self.apportionments:
            if ((i.date == date or date is None ) and
                (i.interzone_flow_id == flow_id or flow_id is None) and
                (i.txn_id == trxn_id or trxn_id is None)):

                output.append(i)

        return output


    def print_apportionments(
        self,
        date: str | None = None,
        flow_id: str | None = None,
        txn_id: str | None = None,
    ) -> None:
        """Print final apportionment results in table format."""

        results = [
            result
            for result in self.apportionments
            if (
                (date is None or result.date == date)
                and (
                    flow_id is None
                    or result.interzone_flow_id == flow_id
                )
                and (
                    txn_id is None
                    or result.txn_id == txn_id
                )
            )
        ]

        results.sort(
            key=lambda result: (
                result.date,
                result.interzone_flow_id,
                result.txn_id,
            )
        )

        if not results:
            print("No apportionment results found.")
            return

        rows = []

        for result in results:
            rows.append([
                result.date,
                result.interzone_flow_id,
                result.txn_id,
                f"{result.value:.3f}",
                "Forward" if result.is_forward else "Reverse",
                result.reason or "",
            ])

        headers = [
            "Date",
            "Flow",
            "Transaction",
            "Value",
            "Direction",
            "Reason",
        ]

        widths = [
            max(
                len(headers[index]),
                *(len(row[index]) for row in rows),
            )
            for index in range(len(headers))
        ]

        def render(row: list[str]) -> str:
            cells = []

            for index, value in enumerate(row):
                if index == 3:
                    cells.append(value.rjust(widths[index]))
                else:
                    cells.append(value.ljust(widths[index]))

            return " | ".join(cells)

        print(render(headers))
        print(
            "-+-".join(
                "-" * width
                for width in widths
            )
        )

        for row in rows:
            print(render(row))


@dataclass
class SolverOutputApportionment:
    date: str
    interzone_flow_id: str
    txn_id: str
    value: float # A negative value indicates flow in the backward direction - but if it is zero then we need the following:
    is_forward: bool
    reason: str | None = None  # New field to identify the limiting factor


@dataclass
class AccountingGraph:
    zones: list['Zone']
    interzone_flows: list['InterzoneFlow']


@dataclass
class Zone:
    id: str
    type: 'ZoneTypes'
    storage_meas_ids: list[str] = field(default_factory=list)
    accounts: list['ZoneAccount'] = field(default_factory=list)


class ZoneTypes(Enum):
    STREAM = 'stream'
    STORAGE = 'storage'
    USE = 'use'
    IMPORT = 'import'
    SYSTEM_GAIN_LOSS = 'system-gain-loss'
    DEPLETION = 'depletion'


class NaturalFlowMode(Enum):
    ZERO = 'ZERO'
    CALCULATED = 'CALCULATED'
    SPECIFIED = 'SPECIFIED'


class FlowComponentsTypes(Enum):
    OBSERVATION = 'OBSERVATION'
    FLOW_BALANCE_OF_DESTINATION_ZONE = 'DESTINATION ZONE'
    FLOW_BALANCE_OF_SOURCE_ZONE = 'SOURCE ZONE'
    OVERLAPPING_SERVICE_AREAS = 'OVERLAPPING SERVICE AREAS'
    EMPTY = 'EMPTY'                                                            # TODO - This should not be an option long-term...
                                                                               #      - It's here to support legacy techniques that should be updated.
@dataclass
class FlowMeasurement: # This is a new class.
    measurement_id: str
    adjustment_factor: float = 1



@dataclass
class InterzoneFlow:
    id: str
    from_zone: str
    to_zone: str
    bidirectional: bool = False

    flow_type: FlowComponentsTypes = FlowComponentsTypes.OBSERVATION
    flow_measurements: list[FlowMeasurement]= field(default_factory=list)

    lag_from_zone: float = 0
    lag_to_zone: float = 0
    loss_from_zone: LossDefinition = field(default_factory=LossDefinition)
    loss_to_zone: LossDefinition = field(default_factory=LossDefinition)

    # Natural-flow configuration. When natural_flow_mode is None, the
    # solver selects the default from the connected zone types.
    natural_flow_mode: NaturalFlowMode | None = None
    nf_measurements: list['FlowMeasurement'] = field(default_factory=list)

    # Not implemented yet - An InterzoneFlow may not neccessaraly be active for the entire run period.
    beg_date: str = '1000-01-01'
    end_date: str = '9999-12-31'

    @property
    def residual_for_gains(self) -> bool:
        if self.flow_type == FlowComponentsTypes.FLOW_BALANCE_OF_DESTINATION_ZONE:
            return True
        if self.flow_type == FlowComponentsTypes.FLOW_BALANCE_OF_SOURCE_ZONE:
            return self.bidirectional
        return False

    @property
    def residual_for_losses(self) -> bool:
        if self.flow_type == FlowComponentsTypes.FLOW_BALANCE_OF_DESTINATION_ZONE:
            return self.bidirectional
        if self.flow_type == FlowComponentsTypes.FLOW_BALANCE_OF_SOURCE_ZONE:
            return True
        return False


    def __post_init__(self):
        for name in ('lag_from_zone', 'lag_to_zone'):
            lag = getattr(self, name)

            if (
                isinstance(lag, bool)
                or not isinstance(lag, (int, float))
                or not isfinite(lag)
            ):
                raise ValueError(
                    f"{name} must be a finite number of days: {lag!r}"
                )

            if lag < 0:
                raise ValueError(
                    f'{name} cannot be negative: {lag}'
                )

    def set_default_natural_flow_mode(self, from_type:ZoneTypes, to_type:ZoneTypes):
        if self.natural_flow_mode is None:
            types = {from_type, to_type}
            if types == {ZoneTypes.STREAM}:
                self.natural_flow_mode = NaturalFlowMode.CALCULATED
            elif types == {ZoneTypes.STREAM, ZoneTypes.SYSTEM_GAIN_LOSS}:
                self.natural_flow_mode = NaturalFlowMode.CALCULATED
            else:
                self.natural_flow_mode = NaturalFlowMode.ZERO


@dataclass
class ZoneAccount:
    """
    An account located in a single zone. Multiple transactions may deposit
    into or withdraw from the same account.

    Balances use the same quantity units as transaction apportionments.
    ``starting_balance`` is the balance at the beginning of SolverInput.beg_date.
    """
    id: str

    # The balance as of the beg-date of beg_date of SolverInput.
    starting_balance: float = 0

    # Do not allow incoming transactions to increase the balance above this.
    balance_ceiling: float | None = None

    # Do not allow outgoing transactions to reduce the balance below this.
    balance_floor: float | None = None

    def __post_init__(self):
        for field_name in ("starting_balance", "balance_ceiling", "balance_floor"):
            value = getattr(self, field_name)
            if value is not None and (not isinstance(value, (int, float)) or not isfinite(value)):
                raise ValueError(
                    f"ZoneAccount {self.id!r} {field_name} must be a finite number or None."
                )

        if (
            self.balance_floor is not None
            and self.balance_ceiling is not None
            and self.balance_floor > self.balance_ceiling
        ):
            raise ValueError(
                f"ZoneAccount {self.id!r} balance_floor cannot exceed "
                f"balance_ceiling: {self.balance_floor} > {self.balance_ceiling}."
            )


@dataclass
class TrxnBaseClass:
    id: str
    priority: float = DEFAULT_TRXN_PRIORITY

    upper_limit: 'float | AccountingLimit | None' = None

    # Cumulative allocation cap. The running total is tracked across solver
    # days and resets before solving the configured month/day. ``None`` means
    # there is no cumulative cap.
    cumulative_limit: float | None = None
    cumulative_reset_before_MMDD: str | None = None

    # Optional user call. This is resolved by date in exactly the same way as
    # upper_limit and participates in the effective daily transaction cap.
    call_limit: 'float | AccountingLimit | None' = None

    wrnum: str | None = None
    beg_date: str | None = None
    end_date: str | None = None

    # What if we want to use the remaining_account_balance as the equal-priority proportion factor?

    def __post_init__(self):
        """Validates the data."""
        if isinstance(self.upper_limit, (int, float)) and self.upper_limit < 0:
            raise ValueError(
                f'Accounting limit cannot be negative: '
                f'{self.upper_limit} '
            )

        if isinstance(self.call_limit, (int, float)) and self.call_limit < 0:
            raise ValueError(
                f'Call limit cannot be negative: {self.call_limit} for Trxn {self.id}'
            )

        if self.cumulative_limit is not None:
            if (
                isinstance(self.cumulative_limit, bool)
                or not isinstance(self.cumulative_limit, (int, float))
                or not isfinite(self.cumulative_limit)
                or self.cumulative_limit < 0
            ):
                raise ValueError(
                    f'cumulative_limit must be a finite non-negative number: '
                    f'{self.cumulative_limit!r} for Trxn {self.id}'
                )

        if self.cumulative_reset_before_MMDD is not None:
            raw_mmdd = self.cumulative_reset_before_MMDD.replace('-', '')
            if len(raw_mmdd) != 4 or not raw_mmdd.isdigit():
                raise ValueError(
                    f'cumulative_reset_MMDD must use MMDD or MM-DD format: '
                    f'{self.cumulative_reset_before_MMDD!r} for Trxn {self.id}'
                )
            try:
                date(2000, int(raw_mmdd[:2]), int(raw_mmdd[2:]))
            except ValueError as exc:
                raise ValueError(
                    f'Invalid cumulative_reset_MMDD '
                    f'{self.cumulative_reset_before_MMDD!r} for Trxn {self.id}'
                ) from exc

        if self.priority < 0 or self.priority > DEFAULT_TRXN_PRIORITY:
            raise ValueError(
                f'priority must be >= 0 and <= {DEFAULT_TRXN_PRIORITY}:'
                f'{self.priority} for TrxnGroup {self.id}'
            )


@dataclass
class PathTrxn(TrxnBaseClass):
    path: list['TrxnPathItem'] = field(default_factory=list)
    from_account: str | None = None # A ZoneAccount id
    to_account: str | None = None   # A ZoneAccount id

    #from_nf: bool = False                                                     # TODO - if I activate this, I need to remember to check it inside of _source_nf_is_exhausted

    is_slack: bool = False                                                     # TODO - this info should be stored elsewhere -- the user should not be exposed to this concept


    def __post_init__(self):
        """Validates the data."""

        if isinstance(self.upper_limit, (int, float)) and self.upper_limit < 0:
            raise ValueError(
                f'Accounting limit cannot be negative: '
                f'{self.upper_limit} '
            )

        if isinstance(self.call_limit, (int, float)) and self.call_limit < 0:
            raise ValueError(
                f'Call limit cannot be negative: {self.call_limit} for Trxn {self.id}'
            )

        if self.cumulative_limit is not None:
            if (
                isinstance(self.cumulative_limit, bool)
                or not isinstance(self.cumulative_limit, (int, float))
                or not isfinite(self.cumulative_limit)
                or self.cumulative_limit < 0
            ):
                raise ValueError(
                    f'cumulative_limit must be a finite non-negative number: '
                    f'{self.cumulative_limit!r} for Trxn {self.id}'
                )

        if self.cumulative_reset_before_MMDD is not None:
            raw_mmdd = self.cumulative_reset_before_MMDD.replace('-', '')
            if len(raw_mmdd) != 4 or not raw_mmdd.isdigit():
                raise ValueError(
                    f'cumulative_reset_MMDD must use MMDD or MM-DD format: '
                    f'{self.cumulative_reset_before_MMDD!r} for Trxn {self.id}'
                )
            try:
                # Leap year permits 0229 while still rejecting invalid dates.
                date(2000, int(raw_mmdd[:2]), int(raw_mmdd[2:]))
            except ValueError as exc:
                raise ValueError(
                    f'Invalid cumulative_reset_MMDD '
                    f'{self.cumulative_reset_before_MMDD!r} for Trxn {self.id}'
                ) from exc

        if self.priority < 0 or self.priority > DEFAULT_TRXN_PRIORITY:
            raise ValueError(
                f'priority must be >= 0 and <= {DEFAULT_TRXN_PRIORITY}:'
                f'{self.priority} for Trxn {self.id}'
            )

        if self.is_slack:
            self.priority = SLACK_TRXN_PRIORITY


@dataclass
class TrxnGroup(TrxnBaseClass):
    """A constraint that applies to a group of Transactions.
    """
    children_trxns: list['PathTrxn | TrxnGroup'] = field(default_factory=list)



@dataclass
class TrxnPathItem:
    flow_id: str
    factor: float = 1                                          # previously 'direction_factor'

    # Only used for unit tests to check if the calculated value is correct
    expected_values: list[float] | None = None

    # The fraction (0-1) of the flow that is lost before the flow of this path
    # item. (If the direction-factor is 1, this means the loss occurs at the
    # from-zone.)
    loss_before: float = 0

    # The fraction (0-1) of the flow that is lost to immediately after the flow
    # of this path item. (If the direction-factor is 1, this means the loss
    # occurs at to-zone.)
    loss_after: float = 0

    # This should not be set directly
    remaining_factor: float = 1

    def __post_init__(self):
        if not isfinite(self.factor) or self.factor == 0:
            raise ValueError(
                f"Transaction path factor must be a finite, non-zero value: "
                f"{self.factor}"
            )

        if not 0 <= self.loss_before <= 1:
            raise ValueError(
                f"loss_before must be between 0 and 1: "
                f"{self.loss_before}"
            )

        if not 0 <= self.loss_after <= 1:
            raise ValueError(
                f"loss_after must be between 0 and 1: "
                f"{self.loss_after}"
            )

    def init_remaining_factor(self, rem_factor:float) -> float:
        """This function is meant to be called in sequence for all of the path
        items in a trxn, so we get the remaining factor given all preceding
        losses. """
        self.remaining_factor = rem_factor * (1-self.loss_before)
        return self.remaining_factor * (1-self.loss_after)


@dataclass
class AccountingLimit:
    intervals: list['AccountingLimitInterval']

    def __post_init__(self):
        self.intervals.sort(key=lambda x: x.beg_date)

        for previous, current in zip(
            self.intervals,
            self.intervals[1:],
        ):
            if current.beg_date < previous.end_date:
                raise ValueError(
                    "Accounting limit intervals overlap: "
                    f"{previous.beg_date} to {previous.end_date} and "
                    f"{current.beg_date} to {current.end_date}"
                )

@dataclass
class AccountingLimitInterval:
    beg_date: str
    end_date: str
    value: float

    def __post_init__(self):
        """Validates the data."""
        if self.value < 0:
            raise ValueError(
                f'Accounting limit cannot be negative: '
                f'{self.value} '
                f'({self.beg_date} to {self.end_date})'
            )

        try:
            beg = date.fromisoformat(self.beg_date)
            end = date.fromisoformat(self.end_date)
        except ValueError as exc:
            raise ValueError(
                "Accounting limit dates must use YYYY-MM-DD format: "
                f"{self.beg_date!r} to {self.end_date!r}"
            ) from exc

        if beg >= end:
            raise ValueError(
                "Accounting limit beg_date must be before end_date: "
                f"{self.beg_date} to {self.end_date}"
            )


@dataclass
class MeasurementSeries:
    id: str
    values: list[float | None]


@dataclass
class MeasurementCollection:
    series: list[MeasurementSeries]
    beg_date: str
    end_date: str # NOTE: this is an inclusive date. TODO: Consider changing name to avoid confusion with exclusive end_dates

    _series_by_id: dict[str, MeasurementSeries] = field(
        init=False,
        repr=False,
    )

    def __post_init__(self):
        beg = date.fromisoformat(self.beg_date)
        end = date.fromisoformat(self.end_date)

        if end < beg:
            raise ValueError(
                f"Measurement end_date {self.end_date} "
                f"is before beg_date {self.beg_date}."
            )

        expected_length = (end - beg).days + 1

        self._series_by_id = {}

        for series in self.series:
            if series.id in self._series_by_id:
                raise ValueError(
                    f"Duplicate measurement id: {series.id!r}"
                )

            if len(series.values) != expected_length:
                raise ValueError(
                    f"Measurement {series.id!r} has "
                    f"{len(series.values)} values; expected "
                    f"{expected_length} for {self.beg_date} "
                    f"through {self.end_date}."
                )

            self._series_by_id[series.id] = series

    def get(
        self,
        measurement_id: str,
        date_string: str,
        lag: float = 0,
    ) -> float | None:

        whole = floor(lag)
        fraction = lag - whole

        newer = self._get_value(
            measurement_id,
            date_string,
            whole,
        )

        if isclose(fraction, 0):
            return newer

        older = self._get_value(
            measurement_id,
            date_string,
            whole + 1,
        )

        if newer is None or older is None:
            return None

        return (
            newer * (1 - fraction)
            + older * fraction
        )

    def _get_value(
        self,
        measurement_id: str,
        date_string: str,
        lag: int = 0,
    ):
        try:
            series = self._series_by_id[str(measurement_id)]
        except KeyError:
            raise ValueError(
                f"Measurement {measurement_id!r} not recognized."
            )

        beg = date.fromisoformat(self.beg_date)
        current = date.fromisoformat(date_string)

        index = (current - beg).days - lag

        if 0 <= index < len(series.values):
            return series.values[index]

        return None

    def get_change(
        self,
        measurement_id: str,
        date_string: str,
        lag: float = 0,
    ) -> float | None:

        today = self.get(
            measurement_id,
            date_string,
            lag,
        )

        yesterday = self.get(
            measurement_id,
            date_string,
            lag + 1,
        )

        if today is None or yesterday is None:
            return None

        return today - yesterday


#
# Classes used for purposes internal to the solver.
#.


@dataclass
class CoreScheduleVariable:
    var: PathTrxn | TrxnGroup

    def __str__(self):
        return f'ScheduleVariable: {self.var.id}'


@dataclass
class CoreSeqSchedule:
    """ """
    series: list['CoreSeqScheduleItem']

    def __str__(self):

        def tab(s:str):
            return s.replace('\n', '\n...')
        return (f'SeqSchedule: ' +
                tab(''.join('\n('+str(idx+1)+'). '+str(i)
                            for idx, i in enumerate(self.series))))


@dataclass
class CorePropSchedule:
    """ """
    series: list['CorePropScheduleItem']

    def __str__(self):

        def tab(s:str):
            return s.replace('\n', '\n...')
        return (f'PropSchedule: ' +
                tab(''.join('\n(*). '+str(i)
                            for idx, i in enumerate(self.series))))


@dataclass
class CoreSeqScheduleItem:
    """A variable or sub-schedule along with the sequential priority."""
    priority: float
    item: CoreScheduleVariable | CoreSeqSchedule | CorePropSchedule

    def __str__(self):
        return f'SeqScheduleItem: priority={self.priority}, item={self.item}'


@dataclass
class CorePropScheduleItem:
    """A variable or sub-schedule along with a proportionality factor."""
    factor: float
    item: CoreScheduleVariable | CoreSeqSchedule | CorePropSchedule

    def __str__(self):
        return f'PropScheduleItem: factor={self.factor}, item={self.item}'


